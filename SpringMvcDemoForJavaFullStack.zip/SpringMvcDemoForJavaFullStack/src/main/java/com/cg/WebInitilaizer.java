package com.cg;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

//FrontController
public class WebInitilaizer extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	
	//Class[] arr=new Class[]{};
	@Override
	protected Class<?>[] getServletConfigClasses() {
		
		return new Class[]{MvcConfig.class};
	}

	@Override
	protected String[] getServletMappings() {
		// TODO Auto-generated method stub
		return new String[]{"/"};   //localhost:8080/     "/student/*","/employee/*"
	}

}
