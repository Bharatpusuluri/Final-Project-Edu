package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class GreetController {

	@RequestMapping("/greet")
	public ModelAndView showView()
	{
		ModelAndView mav=new ModelAndView();
		
		mav.setViewName("result.jsp");
		
		mav.addObject("result","Welcome to EduBridge India!!!");
		
		return mav;
	}
}
